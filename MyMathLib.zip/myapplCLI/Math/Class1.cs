﻿using System;
using MyMathLib;
namespace Math
{
    public class Class1
    {


    }
}
