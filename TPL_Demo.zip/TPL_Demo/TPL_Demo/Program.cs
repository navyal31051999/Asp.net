﻿using System;
using System.Threading.Tasks;
namespace TPL_Demo
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Implementation Of Tasks!");
           
            var task1 = new Task(() =>
            {
                Console.WriteLine("This is a demo of using new keyword \n");
            });

            Task.Factory.StartNew(() =>
            {
                Console.WriteLine("This is a demo of using Task.Factory.StartNew ");
            });
          
            var task = new Task(() =>
            {
                Console.WriteLine("This is the second method to create a task using TPL\n");
            });
          
            
            task1.Start();
            task1.Wait();
            task.Start();
           
            
            Console.Write("Task Complete...\n");
            Console.ReadKey();
        }
    }
}
