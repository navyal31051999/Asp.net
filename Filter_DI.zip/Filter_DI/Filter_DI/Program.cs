using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Filter_DI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }

    public class FilterwithDI : IActionFilter
    {
        private ILogger _logger;
        public FilterwithDI(ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<FilterwithDI>();
        }
        public void OnActionExecuting(ActionExecutingContext context)
        {
          
            _logger.LogInformation("OnActionExecuting");
        }
        public void OnActionExecuted(ActionExecutedContext context)
        {
            //To do : after the action executes  
            _logger.LogInformation("OnActionExecuted");
        }
    }
}