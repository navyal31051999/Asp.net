﻿using EF_MVC.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static EF_MVC.Controllers.HomeController;

namespace EF_MVC.Controllers
{
    public class DemoController : Controller
    {
        public IActionResult Index([FromServices] IHelloWorldService helloWorldService)
            {
                ViewData["MyText"] = helloWorldService.SaysHello() + "Navyaa!";
                return View();
            }
        public IActionResult Index1()
        {
            var helloWorldService = (IHelloWorldService)this.HttpContext.RequestServices.GetService(typeof(IHelloWorldService));
            ViewData["MyText"] = helloWorldService.SaysHello() + "Navya L!";
            return View("index1");
        }

    }
}
