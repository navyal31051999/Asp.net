using System;

namespace EF_MVC.Models
{
    public class ErrorViewModel
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
    public interface IMyDependency
    {
        void WriteMessage(string message);
    }

    public interface IHelloWorldService
    {
        string SaysHello();
    }
      public class HelloWorldService : IHelloWorldService
    {
        public string SaysHello()
        {
            return "Hello ";
        }
    }
}
