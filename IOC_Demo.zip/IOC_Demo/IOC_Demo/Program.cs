﻿using System;
using Microsoft.Practices.Unity;
using System.Collections.Generic;
using System.Linq.Expressions;
using Microsoft.Practices.Unity.Tracking;
using Unity;


namespace IOC_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Implementation of Dependency Injection using Unity Container in COnsole Application\n");

            UnityContainer IU = new UnityContainer();
            //Registering  the types in Container
            IU.RegisterType<BL>();
            IU.RegisterType<DL>();

            IU.RegisterType<IProduct, DL>();
            //Registering  and Injecting Interface into DL layer


            //Object Of Class will be used to Call method defined inside DL class Via Ref Of IProduct
            BL objDL = IU.Resolve<BL>();
            objDL.Write();

            Console.ReadLine();


        }
    }
}
