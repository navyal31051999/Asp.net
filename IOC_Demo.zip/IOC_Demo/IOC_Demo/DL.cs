﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOC_Demo
{
    class DL : IProduct
    {

       
        string IProduct.InsertData()
        {
            string val = "Dependency variable Injected";
               Console.WriteLine(val);
            return val;
            throw new NotImplementedException();
        }
    }
}
